#pragma once
#include "YOUR_LIBRARY_2_NAME_export.h"
class YOUR_LIBRARY_2_NAME_EXPORT lib2
{
 private:
  /* data */
 public:
  lib2(/* args */);
  ~lib2();
};
