#pragma once
class lib2
{
 private:
  /* data */
 public:
  lib2(/* args */);
  ~lib2();
};
