#pragma once
//#include "YOUR_LIBRARY_2_NAME_export.h"
class lib2
{
 private:
  /* data */
 public:
  lib2(/* args */);
  ~lib2();
};
