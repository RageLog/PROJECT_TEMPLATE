#pragma once
#include "YOUR_LIBRARY_1_NAME_export.h"
class YOUR_LIBRARY_1_NAME_EXPORT lib1_2
{
 private:
  /* data */
 public:
  lib1_2(/* args */);
  ~lib1_2();
};
