#pragma once

class lib1_1
{
 private:
  /* data */
 public:
  lib1_1(/* args */);
  ~lib1_1();
};
