#pragma once
//#include "YOUR_LIBRARY_1_NAME_export.h"
//class YOUR_LIBRARY_1_NAME_EXPORT lib1_1

class lib1_1
{
 private:
  /* data */
 public:
  lib1_1(/* args */);
  ~lib1_1();
};
