#Project template for cmake.
->this is provide to you that, cmake-git-software parallel versioning, guiding to project,fast development.