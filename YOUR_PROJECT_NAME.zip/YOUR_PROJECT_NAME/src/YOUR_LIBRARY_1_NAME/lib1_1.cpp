#include "./YOUR_LIBRARY_1_NAME/lib1_1.hpp"

lib1_1::lib1_1()
{
}

lib1_1::~lib1_1()
{
}
