#include "./YOUR_LIBRARY_1_NAME/lib1_2.hpp"

lib1_2::lib1_2(/* args */)
{
}

lib1_2::~lib1_2()
{
}
