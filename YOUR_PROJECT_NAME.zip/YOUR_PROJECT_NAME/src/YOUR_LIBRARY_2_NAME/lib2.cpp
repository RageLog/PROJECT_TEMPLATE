#include "./YOUR_LIBRARY_2_NAME/lib2.hpp"

lib2::lib2(/* args */)
{
}

lib2::~lib2()
{
}
