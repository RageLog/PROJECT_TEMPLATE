
#ifndef YOUR_LIBRARY_1_NAME_EXPORT_H
#define YOUR_LIBRARY_1_NAME_EXPORT_H

#ifdef YOUR_LIBRARY_1_NAME_STATIC_DEFINE
#  define YOUR_LIBRARY_1_NAME_EXPORT
#  define YOUR_LIBRARY_1_NAME_NO_EXPORT
#else
#  ifndef YOUR_LIBRARY_1_NAME_EXPORT
#    ifdef YOUR_LIBRARY_1_NAME_EXPORTS
        /* We are building this library */
#      define YOUR_LIBRARY_1_NAME_EXPORT __declspec(dllexport)
#    else
        /* We are using this library */
#      define YOUR_LIBRARY_1_NAME_EXPORT __declspec(dllimport)
#    endif
#  endif

#  ifndef YOUR_LIBRARY_1_NAME_NO_EXPORT
#    define YOUR_LIBRARY_1_NAME_NO_EXPORT 
#  endif
#endif

#ifndef YOUR_LIBRARY_1_NAME_DEPRECATED
#  define YOUR_LIBRARY_1_NAME_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef YOUR_LIBRARY_1_NAME_DEPRECATED_EXPORT
#  define YOUR_LIBRARY_1_NAME_DEPRECATED_EXPORT YOUR_LIBRARY_1_NAME_EXPORT YOUR_LIBRARY_1_NAME_DEPRECATED
#endif

#ifndef YOUR_LIBRARY_1_NAME_DEPRECATED_NO_EXPORT
#  define YOUR_LIBRARY_1_NAME_DEPRECATED_NO_EXPORT YOUR_LIBRARY_1_NAME_NO_EXPORT YOUR_LIBRARY_1_NAME_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef YOUR_LIBRARY_1_NAME_NO_DEPRECATED
#    define YOUR_LIBRARY_1_NAME_NO_DEPRECATED
#  endif
#endif

#endif /* YOUR_LIBRARY_1_NAME_EXPORT_H */
