#include "gtest/gtest.h"

TEST(ExempleTests, ExempleTestes)
{
  EXPECT_TRUE(true);

  EXPECT_TRUE(true);

  EXPECT_TRUE(true);
}